package com.smartparking.domain.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ParkingSpot {
    private String spotId;
    private String location;
    private boolean occupied;
    private BigDecimal pricePerHour;
    private String parkingLotId;
}