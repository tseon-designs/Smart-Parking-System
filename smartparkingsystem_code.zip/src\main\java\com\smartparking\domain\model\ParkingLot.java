package com.smartparking.domain.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Aggregate root representing a parking lot.
 * Contains business logic for vehicle check‑in/out and spot management.
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ParkingLot {
    private String parkingLotId;
    private String name;
    private int totalSpots;

    // This is a conceptual aggregate; we don't store the list of spots here.
    // Business methods will use repositories to enforce invariants.
}