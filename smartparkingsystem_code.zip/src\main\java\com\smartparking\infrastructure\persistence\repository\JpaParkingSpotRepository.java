package com.smartparking.infrastructure.persistence.repository;

import com.smartparking.domain.model.ParkingSpot;
import com.smartparking.domain.repository.ParkingSpotRepository;
import com.smartparking.infrastructure.persistence.entity.ParkingSpotEntity;
import lombok.RequiredArgsConstructor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

interface SpringDataParkingSpotRepository extends JpaRepository<ParkingSpotEntity, String> {
    List<ParkingSpotEntity> findAllByOccupiedFalse();

    long countByOccupiedTrue();
}

@Repository
@RequiredArgsConstructor
public class JpaParkingSpotRepository implements ParkingSpotRepository {

    private final SpringDataParkingSpotRepository springRepo;

    @Override
    public List<ParkingSpot> findAllByOccupiedFalse() {
        return springRepo.findAllByOccupiedFalse().stream()
                .map(this::toDomain)
                .collect(Collectors.toList());
    }

    @Override
    public Optional<ParkingSpot> findById(String spotId) {
        return springRepo.findById(spotId).map(this::toDomain);
    }

    @Override
    public ParkingSpot save(ParkingSpot spot) {
        ParkingSpotEntity entity = toEntity(spot);
        ParkingSpotEntity saved = springRepo.save(entity);
        return toDomain(saved);
    }

    @Override
    public void deleteById(String spotId) {
        springRepo.deleteById(spotId);
    }

    @Override
    public long count() {
        return springRepo.count();
    }

    @Override
    public long countByOccupiedTrue() {
        return springRepo.countByOccupiedTrue();
    }

    private ParkingSpot toDomain(ParkingSpotEntity entity) {
        return new ParkingSpot(
                entity.getSpotId(),
                entity.getLocation(),
                entity.isOccupied(),
                entity.getPricePerHour(),
                entity.getParkingLotId());
    }

    private ParkingSpotEntity toEntity(ParkingSpot spot) {
        return new ParkingSpotEntity(
                spot.getSpotId(),
                spot.getLocation(),
                spot.isOccupied(),
                spot.getPricePerHour(),
                spot.getParkingLotId());
    }
}